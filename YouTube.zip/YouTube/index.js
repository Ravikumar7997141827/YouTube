let menubtn = document.querySelector(".menu-btn");
let sidebar = document.querySelector(".side-bar");
let videosContainer = document.querySelector(".video-container");


menubtn.onclick = function () {
   sidebar.classList.toggle("resize-sidebar");
   videosContainer.classList.toggle("widen-videos-container")
}


let toggleBtn=document.querySelector('.toggleBtn');
let body=document.querySelector('body');
toggleBtn.onclick=function(){
   body.classList.toggle('dark')
}








var admin = require("firebase-admin");

var serviceAccount = require("path/to/serviceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});
